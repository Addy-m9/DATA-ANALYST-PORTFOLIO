# SQL_Project_Music_Store_Analysis
SQL project to analyze online music store data.In this project I have examine the dataset with SQL and help the store understand its business growth.

## Database and Tools
* Postgre SQL
* PgAdmin4

Schema- Music Store Database  

